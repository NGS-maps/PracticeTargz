#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include "dendromat.h"

extern node_data *nodes;
extern line_info *lines;
extern int n_nodes;
extern int n_line;
extern int font_size;
extern int n_term;
extern term_info *terms;
extern int dmaptype;
extern int caption_type;
extern int auto_scale;
extern int auto_center;
extern float line_width;

extern char font_name[];
extern int separation;
extern int shift;
extern int page_height    ;   //A4 height pt = 209.17mm
extern int page_width     ;   //A4 width  pt = 295.8 mm
extern int page_height_a3 ;   //A3 height pt = 418.5 mm
extern int page_width_a3  ;   //A3 width  pt = 295.8 mm
extern int area_height    ;   //A3 width  pt = 295.8 mm
extern int area_width     ;   //A3 width  pt = 295.8 mm
extern int left_margin    ;
extern int right_margin   ;
extern int top_margin     ;
extern int bottom_margin  ;
extern int center_node;
extern int side;
extern float longest_line;
extern float shortest_line;
extern int nl2;
extern int bootstrap;

void define_lines(int point, int prev);
/////////////////////////////////////////////////////////////// FUNCTION shifth
void shifth(double shiftx, double shifty, int currentline);
/////////////////////////////////////////////////////////////// END FUNCTION shifth

///////////////////////////////////////////////////////////////////// START mk_dendrogram2
void mk_phylogram(char *outflnm)
{
int i,j,k;
FILE *outfile;
float scale;
int nl = 0;
int cc;
float increment = 0.0;
float v_pos = 0.0;
float angle = 0.0;
float temp;
int count;
int all_done = 0;
int test;
float shiftx, shifty;
float sx, sy;
float length;
float leftmost = 999999.0;
float rightmost = -999999.0;
float upmost = -999999.0;
float downmost = 999999.0;
float width,height;
float sideshift;
float vertshift;
float ps_scale;
float temp1,temp2;
float a1,a2;
int fr, to;
float mid_point;
float x_y_ratio;
int ii;
int it[2000];

///////////////////////////////////////////////////////////////////ALLOCATE STRUCTURE FOR lines
lines = (line_info *) malloc (sizeof(line_info) * (n_line + 5));
///////////////////////////////////////////////////////////////////ALLOCATE STRUCTURE FOR lines

printf("ENTER MK_PHYLOGRAM \n");

nl2 = 0;                                 // counter for number of lines
longest_line = 0.0;
shortest_line = 999999.0;

////////////////////////////////////////////////////////////////// FILL STRUCTURE lines
nl = 0;
for(i=1;i<=n_nodes;i++)
 for(j=0;j<3;j++)
  if((nodes[i].ne[j].string[0] != '\0') || (nodes[i].ne[j].pointer != 0))
   {
   lines[nl].fr_node = i;
   lines[nl].to_node   = nodes[i].ne[j].pointer;   // 0 if terminal
   lines[nl].angle     = 0.0;
   lines[nl].length    = nodes[i].ne[j].distance;
   if(lines[nl].length > longest_line)
    longest_line = lines[nl].length;
   if(lines[nl].length < shortest_line)
    shortest_line = lines[nl].length;
   lines[nl].frx       = 0.0;
   lines[nl].fry       = 0.0;
   lines[nl].tox       = 0.0;
   lines[nl].toy       = 0.0;
   lines[nl].done_flag = 0;
   lines[nl].type      = 2;
   lines[nl].point[0]  = 0;
   lines[nl].point[1]  = 0;
   lines[nl].i = i;
   lines[nl].j = j;
   if(lines[nl].to_node <= -1)
    {
    lines[nl].term_flag = 1;
    lines[nl].type      = 1;
    }
   if(i == 1)
    lines[nl].type = 3;
   nl++;
   }
//////////////////////////////////////////////////////////////////  END FILLING STRUCTURE lines

for(i=0;i<n_line;i++)
 {
 cc = 0;
 if(lines[i].to_node > 0)
  {
  for(j=0;j<n_line;j++)
   {
   if(lines[j].fr_node == lines[i].to_node)
    {
    lines[i].point[cc] = j+1;
    cc ++;
    }
   }
  }
 }

//for(i=0;i<n_term;i++)
// printf("TERM %3d %s \n", i+1,terms[i].name);

if(longest_line < 0.0000001)
 {
 for(i=0;i<n_line;i++)
  lines[i].length = 50.0;
 longest_line = 150.0;
 }

scale = 200.0/longest_line;

increment = 1.0 / ((float)(n_term));
//increment = 360.0 / ((float)(n_term));

//printf("NUMBER OF TERMINAL NODE = %5d N_LINES %5d\n",n_term,nl);

//////////////////////////////////////////////////////////////////  set start and end positions of each line, for all terminal lines
for(i=1;i<=nl;i++)
 {
 v_pos += increment;
// angle += increment;
// if(angle > 360.0)
//  angle = 360.0;
 for(j=0;j<nl;j++)
  {
  if(lines[j].to_node == -(i))
   {
   lines[j].done_flag = 1;
   lines[j].frx = 0.0;
   lines[j].fry = v_pos;
   lines[j].tox = lines[j].length;
   lines[j].toy = v_pos;
   for(k=0;k<3;k++)
    nodes[lines[j].fr_node].ne[k].done_flag++;
//printf("INIT:%5d %5d %5d %10.4f %10.4f %10.4f=%10.4f %10.4f=%10.4f %5d\n",j,lines[j].fr_node,lines[j].to_node,angle,lines[j].length,lines[j].frx,lines[j].fry,lines[j].tox,lines[j].toy,lines[j].done_flag);
   break;
   }
  }
 }
//////////////////////////////////////////////////////////////////  set positions for terminal lines

//for(i=0;i<=nl;i++)
// printf("LINES:%5d %5d %5d %10.4f %10.4f %10.4f=%10.4f %10.4f=%10.4f %5d\n",i,lines[i].fr_node,lines[i].to_node,lines[i].angle,lines[i].length,lines[i].frx,lines[i].fry,lines[i].tox,lines[i].toy,lines[i].done_flag);
// LOOP TO GROW THE TREE FROM INSIDE
count = 2;


//////////////////////////////////////////////////////////////////  grow non-terminal lines from inside(center_node)
while (all_done == 0)
 {
 for(i=0;i<nl;i++)
  {
  if(lines[i].done_flag == 0)
   if(lines[i].to_node >= 0)
    {
    test = 0;
    for(j=0;j<3;j++)
     {
     if((nodes[lines[i].to_node].ne[j].pointer < 0) ||
        (nodes[lines[i].to_node].ne[j].done_flag == 2))
      test ++;
     }
    if(test == 3)
     {
     lines[i].done_flag = count;
     for(j=0;j<3;j++)
      nodes[lines[i].fr_node].ne[j].done_flag++;

     mid_point = (lines[lines[i].point[0]-1].fry + lines[lines[i].point[1]-1].fry) / 2.0;

     shiftx = lines[i].length;

     lines[i].tox = shiftx;
     lines[i].toy = mid_point;
     lines[i].frx = 0.0;
     lines[i].fry = mid_point;

//printf("%5d %5d %5d %10.4f %10.4f %10.4f\n",i,lines[i].fr_node,lines[i].to_node,lines[i].length,shifty,shiftx);

     shifth(shiftx,shifty,i);
     }
    }
  }

 all_done = 1;
 for(i=0;i<nl;i++)
  {

  if(lines[i].done_flag == 0)
   {
   all_done = 0;
   }
  }

 count ++;
 }
///////////////////////////////////////////////////////////////// END grow lines from inside (center node)

//MARK

//for(i=0;i<nl;i++)
// printf("LINE %2d FROM %3d TO %3d POINT1 %3d POINT2 %3d DONE %1d TYPE %1d TERM %1d angle %8.3f length %10.6f frx %6.3f fry %6.3f tox %6.3f toy %6.3f\n",
//        i+1,
//        lines[i].fr_node,
//        lines[i].to_node,
//        lines[i].point[0],
//        lines[i].point[1],
//        lines[i].done_flag,
//        lines[i].type,
//        lines[i].term_flag,
//        lines[i].angle,
//        lines[i].length,
//        lines[i].frx,
//        lines[i].fry,
//        lines[i].tox,
//        lines[i].toy
//       );



if(!(outfile = fopen(outflnm,"w")))
 {
 printf("Failed to open output ps file %s.\n",outflnm);
 exit(1);
 }


////////////////////////////////////////////////////////////  Predetermin scale and centering numbers
for(i=0;i<nl;i++)
 if(lines[i].term_flag == 1)
   {
   temp1 = (float)(lines[i].frx * scale);
   temp2 = (float)(lines[i].tox * scale) +  ((float)font_size * 1.0 * ((float)(strlen(nodes[lines[i].i].ne[lines[i].j].name))));
   if(temp1 < leftmost)
    leftmost  = temp1;
   if(temp2 > rightmost)
    rightmost = temp2;

   temp1 = (float)(lines[i].toy);
   if(temp1 > upmost)
    upmost   = temp1;
   if(temp1 < downmost)
    downmost = temp1;
   }

width = rightmost - leftmost;
height = upmost - downmost;
printf("UPMOST %f DOWNMOST %f  RIGHTMOST %f LEFTMOST %f\n",upmost,downmost,rightmost,leftmost);
printf("WIDTH %f HEIGHT %f  \n",width,height);
sideshift = -(rightmost + leftmost)/2.0;
vertshift = -(upmost + downmost)/2.0;
x_y_ratio = width / height * 295.8 / 209.17;
printf("SIDESHIFT %f VERTSHIFT %f  X_Y_RATIO %f\n",sideshift,vertshift,x_y_ratio);
for(i=0;i<nl;i++)
  {
  lines[i].frx = lines[i].frx + (sideshift/scale);
  lines[i].tox = lines[i].tox + (sideshift/scale);
  lines[i].fry = (lines[i].fry + vertshift) * x_y_ratio;
  lines[i].toy = (lines[i].toy + vertshift) * x_y_ratio;
  }
leftmost = 999999.0;
rightmost = -999999.0;
upmost = -999999.0;
downmost = 999999.0;
for(i=0;i<nl;i++)
 if(lines[i].term_flag == 1)
   {
   temp1 = (float)(lines[i].frx * scale);
   temp2 = (float)(lines[i].tox * scale);
   if(temp1 < leftmost)
    leftmost  = temp1;
   if(temp2 > rightmost)
    rightmost = temp2;

   temp1 = (float)(lines[i].toy);
   temp2 = (float)(lines[i].fry);
   if(temp1 > upmost)
    upmost   = temp1;
   if(temp2 < downmost)
    downmost = temp1;
   }
width = rightmost - leftmost;
height = upmost - downmost;

//upmost = upmost * x_y_ratio;
//downmost = downmost * x_y_ratio;
//height = upmost - downmost;
ps_scale = (page_width - 40.0) / width;
if((page_height / height) < ps_scale)
 ps_scale = (page_height - 40.0) / height;
printf("UPMOST %f DOWNMOST %f  RIGHTMOST %f LEFTMOST %f\n",upmost,downmost,rightmost,leftmost);
printf("WIDTH %f HEIGHT %f  \n",width,height);
printf("SIDESHIFT %f VERTSHIFT %f  \n",sideshift,vertshift);
printf("PS_SCALE %f\n",ps_scale);

x_y_ratio = x_y_ratio/scale;
ps_scale = ps_scale * 0.85 ; // MARK

////////////////////////////////////////////////////////////  END predetermine scale and centering numbers

////////////////////////////////////////////////////////////  Start creating PostScript file
// print PostScript header
// fputc('%',outfile);
 fprintf(outfile,"%%!PS-Adobe-\n%%Creator: kenske\n%%CreationDate: Sat Jul 19 16:15:35 2003\n%%DocumentFonts: (atend)\n");
 fprintf(outfile,"%%Pages: (atend)\n%%EndComments\n/mv {moveto} def\n");
 fprintf(outfile,"/right\n {      dup stringwidth pop\n        neg 0 rmoveto} bind def\n");
 fprintf(outfile,"/center\n {      dup stringwidth pop\n        2 div neg 0 rmoveto} bind def\n");
 fprintf(outfile,"%%EndProlog\n%%Page: 1\n");
// fprintf(outfile,"\n /%s findfont %3d scalefont setfont\n %d %d translate\n",font_name,font_size,page_width/2,page_height/2);
// fprintf(outfile,"\n /%s findfont %3d scalefont setfont\n %f %f translate %f %f scale\n",
//        font_name,font_size,((float)page_width/2.0)+sideshift,((float)page_height/2.0)+vertshift,ps_scale,ps_scale);
 fprintf(outfile,"\n /%s findfont %3d scalefont setfont\n %f %f translate %f %f scale\n",
        font_name,font_size,((float)page_width/2.0),((float)page_height/2.0),ps_scale,ps_scale);

it[0] = -1;
it[1] = -1;
it[2] = -1;
ii=0;
for(i=0;i<nl;i++)
  {
  if(lines[i].frx <= 0.0000001)
   {
   it[ii] = i;
   ii++;
   }
  }

//// THIS IS VERTICAL LINE FOR ROOT POSITION, HAS TO BE UPDATED ////////////////////
if((it[0] >= 0) && (it[1] >= 0))
fprintf(outfile,"%f %f moveto\n%f %f lineto\n",(float)(lines[it[0]].frx * scale), 
                                               (float)(lines[it[0]].fry ), 
                                               (float)(lines[it[1]].frx * scale),
                                               (float)(lines[it[1]].fry ));
if((it[1] >= 0) && (it[2] >= 0))
fprintf(outfile,"%f %f moveto\n%f %f lineto\n",(float)(lines[it[1]].frx * scale), 
                                               (float)(lines[it[1]].fry ), 
                                               (float)(lines[it[2]].frx * scale),
                                               (float)(lines[it[2]].fry ));

// print PostScript lines
 for(i=0;i<nl;i++)
  {
  fprintf(outfile,"%f %f moveto\n%f %f lineto\n",(float)(lines[i].frx * scale), (float)(lines[i].fry ), 
                                                 (float)(lines[i].tox * scale), (float)(lines[i].toy ));

  fprintf(outfile,"%f %f moveto\n%f %f lineto\n",(float)(lines[lines[i].point[0]-1].frx * scale), 
                                                 (float)(lines[lines[i].point[0]-1].fry ), 
                                                 (float)(lines[lines[i].point[1]-1].frx * scale),
                                                 (float)(lines[lines[i].point[1]-1].fry ));
///////////////////////////////////////////////////////////// print PostScript captions
  if(lines[i].term_flag == 1)
   {
   fprintf(outfile,"%f %f moveto", (float)(lines[i].tox * scale), (float)(lines[i].toy ));
   if((lines[i].angle <= 80.0) || (lines[i].angle >= 280.0))  // Right Side   
    fprintf(outfile," %d %f rmoveto",separation, -((float)font_size*0.7)/2.0);
   else
    if((lines[i].angle > 80.0) && (lines[i].angle <= 90.0))  // Right UP
     fprintf(outfile," %d %d rmoveto", -shift, separation);
    else
     if((lines[i].angle > 90.0) && (lines[i].angle <= 100.0))  // Left UP
      fprintf(outfile," %d %d rmoveto", shift, separation);
     else
      if((lines[i].angle > 100.0) && (lines[i].angle <= 260.0))  // Left Side
       fprintf(outfile," %d %f rmoveto", -separation, -((float)font_size*0.7)/2.0);
      else
       if((lines[i].angle > 260.0) && (lines[i].angle <= 270.0))  // Left Down
        fprintf(outfile," %d %f rmoveto", shift,-((float)separation+0.8*(float)font_size));
       else
        if((lines[i].angle > 270.0) && (lines[i].angle < 280.0))  // Right Down
         fprintf(outfile," %d %f rmoveto", -shift,-((float)separation+0.8*(float)font_size));
    
   fprintf(outfile," (%s)",nodes[lines[i].i].ne[lines[i].j].name);
   if((lines[i].angle < 90.0) || (lines[i].angle > 270.0))
    fprintf(outfile,"show\n");
   else
    fprintf(outfile,"right show\n");
   }
  }
/////////////////////////////////////////////////////////////// END creating postscript file contents

/////////////////////////////////////////////////////////////// print PostScript footer
 fprintf(outfile,"%f setlinewidth\nstroke\nshowpage\n",line_width);
}
/////////////////////////////////////////////////////////////////////////////////// END mk_dendrogram2 
