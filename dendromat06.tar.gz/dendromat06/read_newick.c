#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include "dendromat.h"

extern node_data *nodes;
extern line_info *lines;
extern term_info *terms;
extern int n_nodes;
extern int n_line;
extern int n_term;
extern int rooted;
extern int unrooted;

void read_newick(char *inflnm)
{
int i,j,k;
char buff[132];
FILE *infile;
int n_par_open  = 0;
int n_par_close = 0;
int n_bra_open  = 0;
int n_bra_close = 0;
int n_semicolon = 0;
int n_colon = 0;
int n_comma = 0;
int depth  = 1;
int node_num  = 1;
int n_digit = 0;
int read_distance = 0;
int read_bootstrap = 0;
char numbuff[80];
int prev_comma = 0;
int prev_open = 0;
int prev_close = 0;
int closed_par = 0;
int stack[1000];
int read_mode = 0;

for(i=0;i<1000;i++)
 stack[i] = 0;
/////////////////////////////////////////// Initial scan
if(!(infile = fopen(inflnm,"r")))
 {
 printf("Failed to open newick format topology file %s.\n",inflnm);
 exit(1);
 }

while(fgets(buff,132,infile))
 {
 for(i=0;i<strlen(buff);i++)
  {
  if(buff[i] == '(')
   n_par_open ++;
  if(buff[i] == ')')
   n_par_close ++;
  if(buff[i] == '[')
   n_bra_open ++;
  if(buff[i] == ']')
   n_bra_close ++;
  if(buff[i] == ',')
   n_comma ++;
  if(buff[i] == ';')
   n_semicolon ++;
  if(buff[i] == ':')
   n_colon ++;
  }
 }
fclose(infile);
/////////////////////////////////////////// END Initial scan

/////////////////////////////////////////// CHECK scan information
if(n_par_open == n_par_close)
 {
 n_nodes = n_par_open;
 if(n_nodes == n_comma)
  {
  printf("The dendrogram is ROOTED\n");
  rooted = 1;
  unrooted = 0;
  }
 else
  {
  printf("The dendrogram is UNROOTED\n");
  rooted = 0;
  unrooted = 1;
  }
 printf("There are %3d nodes\n",n_nodes);
 }
else
 {
 printf("Number of parentheses in Newick file does not match\n Check your input file, please.\n");
 exit(1);
 }

nodes  = (node_data *) malloc (sizeof(node_data) * (n_nodes + 5));
terms = (term_info *) malloc (sizeof(term_info) * (n_nodes * 2 + 5));

for(i=0;i<=n_nodes+4;i++)                              // Initialize nodes
 for(j=0;j<3;j++)
  {
  nodes[i].ne[j].pointer =  0;
  nodes[i].ne[j].bootstrap = -1;
  nodes[i].ne[j].guess_angle = 0.0;
  nodes[i].ne[j].distance = 0.0;
  nodes[i].ne[j].name[0] = '\0';
  nodes[i].ne[j].string[0] = '\0';
  nodes[i].ne[j].shortname[0] = '\0';
  nodes[i].ne[j].done_flag = 0;
  }
/////////////////////////////////////////// END CHECK scan information

/////////////////////////////////////////// READ newick file
if(!(infile = fopen(inflnm,"r")))
 {
 printf("Failed to open newick format topology file %s.\n",inflnm);
 exit(1);
 }

depth = 0;
node_num = 0;
read_distance = 0;
prev_open  = 0;
prev_comma = 0;
prev_close = 0;
while(fgets(buff,132,infile))
 {
 for(i=0;i<strlen(buff);i++)
  {
  if(buff[i] == ';') 
   break;
  if((buff[i] != ' ') && (buff[i] != '\n') && (buff[i] != '\t'))
   {
//printf("%c",buff[i]);
   if(buff[i] == '(')
    {
    if(prev_open == 1)
     nodes[stack[depth]].ne[nodes[stack[depth]].n_e].pointer = node_num+1;
    if(prev_comma == 1)
     nodes[stack[depth]].ne[nodes[stack[depth]].n_e].pointer = node_num+1;
    prev_open  = 1;
    prev_comma = 0;
    prev_close = 0;
    numbuff[0] = '\0';
    n_digit = 0;
    depth ++;
    node_num ++;
    nodes[stack[depth]].n_e = 0;
//printf("NODENUM = %5d\n",node_num);
    stack[depth] = node_num;
    read_distance = 0;
//printf("(:%5d %5d\n",depth,stack[depth]);
    continue;
    }
    if(prev_comma == 1)
     {
     strcpy(nodes[stack[depth]].ne[nodes[stack[depth]].n_e].string,numbuff);
     }
    if(prev_close == 1)
     {
     }
   if(buff[i] == ')')
    {
    if(prev_comma == 1)
     {
     strcpy(nodes[stack[depth]].ne[nodes[stack[depth]].n_e].string,numbuff);
     }
    if(prev_close == 1)
     {
     strcpy(nodes[stack[depth]].ne[nodes[stack[depth]].n_e].string,numbuff);
     }
    prev_open  = 0;
    prev_comma = 0;
    prev_close = 1;
    numbuff[0] = '\0';
    n_digit = 0;
    depth --;
    read_distance = 0;
//printf("):%5d %5d\n",depth,stack[depth]);
    continue;
    }
   if(buff[i] == ',')
    {
    if(prev_open == 1)
     {
     strcpy(nodes[stack[depth]].ne[nodes[stack[depth]].n_e].string,numbuff);
     }
    if(prev_close == 1)
     {
     strcpy(nodes[stack[depth]].ne[nodes[stack[depth]].n_e].string,numbuff);
     }

    prev_open  = 0;
    prev_comma = 1;
    prev_close = 0;
    numbuff[0] = '\0';
    n_digit = 0;
//printf(",:%5d %5d\n",depth,stack[depth]);
    nodes[stack[depth]].n_e ++;
    read_distance = 0;
    continue;
    }
   if((read_distance==0) && (read_bootstrap==0))
    {
//    prev_open  = 0;
//    prev_comma = 0;
//    prev_close = 0;
    numbuff[n_digit++] = buff[i];
    numbuff[n_digit]   = '\0';
    }
   }
  }
 }
//////////////////////////////////////////////// END OF READ NEWICK FILE

//////////////////////////////////////////////// SPLIT, TITLE, DISTANCE and BOOTSTRAP

for(i=1;i<=n_nodes;i++)
 for(j=0;j<3;j++)
  {
  read_mode = 0;
  numbuff[0] = '\0';
  n_digit = 0;
  for(k=0;k<=strlen(nodes[i].ne[j].string);k++)
   {
   if(nodes[i].ne[j].string[k] == '\0')
    {
    if(read_mode == 0)
     {
     strcpy(nodes[i].ne[j].name,numbuff);
     if(strlen(numbuff) > 0)
      {
      strcpy(terms[n_term].name, numbuff);
      nodes[i].ne[j].pointer = -(n_term +1);
      n_term ++;
      }
     }
    if(read_mode == 1)
     nodes[i].ne[j].distance = atof(numbuff);
    continue;
    }
   if(nodes[i].ne[j].string[k] == ':')
    {
    strcpy(nodes[i].ne[j].name,numbuff);
    if(strlen(numbuff) > 0)
      {
      strcpy(terms[n_term].name, numbuff);
      nodes[i].ne[j].pointer = -(n_term +1);
      n_term ++;
      }
    read_mode = 1;
    numbuff[0] = '\0';
    n_digit = 0;
    continue;
    }
   if(nodes[i].ne[j].string[k] == '[')
    {
    nodes[i].ne[j].distance = atof(numbuff);
    read_mode = 2;
    numbuff[0] = '\0';
    n_digit = 0;
    continue;
    }
   if(nodes[i].ne[j].string[k] == ']')
    {
    nodes[i].ne[j].bootstrap = atoi(numbuff);
    continue;
    }
   numbuff[n_digit++] = nodes[i].ne[j].string[k];
   numbuff[n_digit]   = '\0';
   }
  }

//////////////////////////////////////////////// END OF SPLIT, TITLE, DISTANCE and BOOTSTRAP

//for(i=1;i<=n_nodes;i++)
// {
// for(j=0;j<3;j++)
//  {
//  if((nodes[i].ne[j].string[0] != '\0') || (nodes[i].ne[j].pointer != 0))
//   printf("%3d %3d: %4d, %4d, %50s,%40s,%10.6f,%5d, %9.4f\n",i,j,nodes[i].ne[j].pointer,nodes[i].ne[j].done_flag,nodes[i].ne[j].string,nodes[i].ne[j].name,nodes[i].ne[j].distance, nodes[i].ne[j].bootstrap,nodes[i].ne[j].guess_angle);
//  }
// printf("\n");
// }

if(rooted == 0)
 n_line = n_nodes * 2 + 1;
else
 n_line = n_nodes * 2;

printf("NUMBER OF TERMINAL NODE = %5d\n",n_term);
printf("NUMBER OF LINEs         = %5d\n",n_line);

  
fclose(infile);
/////////////////////////////////////////// END READ newick file

}
