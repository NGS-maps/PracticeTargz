#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include "dendromat.h"

extern node_data *nodes;
extern line_info *lines;
extern int n_nodes;
extern int n_line;
extern int n_term;
extern term_info *terms;
extern int unrooted;
extern int center_node;
extern int side;

int count_term(int point,int prev);      // RECURSIVE ROUTINE TO COUNT TERMINAL NODES DOWNSTREAM FROM A NODE point. prev is a node upstream by one.

////////////////////////////////////////////////////////////////////////////////
// CENTRAL (FIRST) NODE OF INPUT NEWICK FILE IS OFTEN OFF CENTERED TOPOLOGICALLY
// IN THE CASE OF UNROOTED DENDROGRAM THIS IS NOT FEASIBLE WHEN A TREE IS DRAWN
// A CENTRAL NODE IS HERE DEFINED AS A SIDE OF A BRANCH THAT SPLITS THE NUMBER
// OF TERMINAL NODE AS EVEN AS POSSIBLE
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////START find_center FUNCTION
void find_center(void)
{
int i,j;
int nn;
int rt = 2;
int *t1;
int *t2;
int *t3;
int point;
int temp;
int mv;
int max;

for(i=1;i<=n_nodes;i++)                       // replace all node data set with 3 pointed nodes
 {
 if((i==1) && (unrooted ==1))
  rt = 3;
 for(j=0;j<rt;j++) 
  {
  if(nodes[i].ne[j].pointer > 0)
   {
   nn = nodes[i].ne[j].pointer;
   nodes[nn].ne[2].pointer = i;
   strcpy(nodes[nn].ne[2].string,nodes[i].ne[j].string);
//printf("%s\n",nodes[i].ne[j].string);
   nodes[nn].ne[2].distance = nodes[i].ne[j].distance;
   }
  }
 rt = 2;
 }

///////////////////////////////////////////// END OF MAKING 3 pointed NODES



//for(i=1;i<=n_nodes;i++)
// {
// for(j=0;j<3;j++) 
//  {
//  if((nodes[i].ne[j].string[0] != '\0') || (nodes[i].ne[j].pointer != 0))
//   printf("%4d %4d: %4d, %4d, %50s,%40s,%10.6f,%5d, %9.4f\n",i,j,nodes[i].ne[j].pointer,nodes[i].ne[j].done_flag,nodes[i].ne[j].string,nodes[i].ne[j].name,nodes[i].ne[j].distance, nodes[i].ne[j].bootstrap,nodes[i].ne[j].guess_angle);
//  }
// printf("\n");  
// }

////////////////////////////////////////////////// ALLOCATE TERMINAL COUNTER
t1 = (int *)malloc(sizeof(int)*(n_nodes*5));
t2 = (int *)malloc(sizeof(int)*(n_nodes*5));
t3 = (int *)malloc(sizeof(int)*(n_nodes*5));
//////////////////////////////////////////////////

////////////////////////////////////////////////// COUNT TERMINAL NODES FROM EACH NODE, THREE WAY
for(i=1;i<=n_nodes;i++)
 {
 t1[i] = 0;
 t2[i] = 0;
 t3[i] = 0;

 point = nodes[i].ne[0].pointer;

 if(point < 0)
  t1[i] = 1;
 else
  {
  temp  = count_term(point,i);
  t1[i] = temp;
  }

 point = nodes[i].ne[1].pointer;
 if(point < 0)
  t2[i] = 1;
 else
  {
  temp  = count_term(point,i);
  t2[i] = temp;
  }

 point = nodes[i].ne[2].pointer;
 if (point < 0)
  t3[i] = 1;
 else
  {
  temp  = count_term(point,i);
  t3[i] = temp;
  }
 }
//////////////////////////////////////////////////

//for(i=1;i<=n_nodes;i++)
// printf("%5d %5d %5d %5d\n",i,t1[i],t2[i],t3[i]);
//printf("\n");

mv = n_term / 2;
max = 0;

////////////////////////////////////////////////// LOOK FOR CENTER NODE BY LOOKING FOR A NODE SEPARATES EVEN NUMBER OF TERMINAL
for(i=1;i<=n_nodes;i++)
 {
 if((t1[i] > max) && (t1[i] <= mv))
  {
  max = t1[i];
  center_node = i;
  side = 0;
  }
 if((t2[i] > max) && (t2[i] <= mv))
  {
  max = t2[i];
  center_node = i;
  side = 1;
  }
 if((t3[i] > max) && (t3[i] <= mv))
  {
  max = t3[i];
  center_node = i;
  side = 2;
  }
 }
//////////////////////////////////////////////////


printf("MV = %5d CENTER = %5d SIDE = %3d\n",mv,center_node,side);


free(t1);
free(t2);
free(t3);
// MARK
//exit (0);
}
/////////////////////////////////////////////END find_center FUNCTION

/////////////////////////////////////////////START SUB FUNCTION count_term
int count_term(int point,int prev)
 {
 int i;
 int count=0;
 for(i=0;i<3;i++)
  {
  if(nodes[point].ne[i].pointer == prev)
   continue;
  if(nodes[point].ne[i].pointer < 0)
   {
   count ++;
   }
  else
   {
//printf("%5d->%5d\n",point,nodes[point].ne[i].pointer);
   count += count_term(nodes[point].ne[i].pointer,point);
   }
  }
 return count;
 }
/////////////////////////////////////////////END SUB FUNCTION count_term
