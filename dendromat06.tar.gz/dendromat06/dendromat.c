#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "dendromat.h"

dend_info *dends;
node_data *nodes;
line_info *lines;
term_info *terms;
int n_nodes=0;
int root_search = 1;
int dmaptype=2;               //0:simple tree, 1:phylogram, 2:dendrogram          
int font_size = 10;
int n_term = 0;
int n_line = 0;
int caption_type = 2;
int auto_scale = 1;
int auto_center = 1;
float line_width = 1.0;
int rooted=0;
int unrooted=0;
int center_node = 0;
int side = 0;
int paper_size = 4;
int bs_flag = 1;

int ps_keep = 0;

//////////////////
// PS VARIABLES //
//////////////////

char font_name[80];
char title[132];
int separation     =    2;
int shift          =    5;
int page_height    =  842;   //A4 height pt = 209.17mm
int page_width     =  595;   //A4 width  pt = 295.8 mm
int page_height_a3 = 1191;   //A3 height pt = 418.5 mm
int page_width_a3  =  842;   //A3 width  pt = 295.8 mm
int area_height    =  791;   //A3 width  pt = 295.8 mm
int area_width     =  485;   //A3 width  pt = 295.8 mm
int left_margin    =  70;
int right_margin   =  40;
int top_margin     =  25;
int bottom_margin  =  25;
int bootstrap      =   1;

char inflnm[132];
char outflnm[132];

int main(int argc, char **argv)
{
int i,j;

strcpy(font_name,"Helvetica");
title[0]='\0';

readargs(argc, argv);                     // Analyze Arguments

read_newick(inflnm);                      // READ INPUT newick format FILE

if((rooted == 1)  || (dmaptype == 1))
 root_search = 0;

printf("DONE READING\n");
if(root_search == 1)                        // LOOK FOR CENTER NODE
 {
 find_center();                             // FIND CENTER NODE (FOR UNROOTED DENDROGRAM)
 if(dmaptype == 2)
  mk_dendrogram2(outflnm);                  // DRAW DENDROGRAM
 if(dmaptype == 1)
  mk_phylogram2(outflnm);                   // DRAW PHYLOGRAM
 }
else                                        // DO NOT LOOK FOR CENTER NODE  like in case of (ROOTED) PHYLOGRAM
 {
 if(dmaptype == 2)
  mk_dendrogram(outflnm);                   // DRAW DENDROGRAM
 if(dmaptype == 1)
  mk_phylogram(outflnm);                    // DRAW PHYLOGRAM
 }

printf("Normal End, Bye!\n");
}
