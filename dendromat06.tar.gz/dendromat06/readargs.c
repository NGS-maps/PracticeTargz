#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include "dendromat.h"

extern char inflnm[];
extern char outflnm[];

extern int dmaptype;               //0:simple tree, 1:tree, 2:dendrogram
extern int bootstrap;
extern int font_size;
extern int n_term;
extern int n_line;
extern int paper_size;
extern int caption_type;
extern char font_name[];
extern char title[];
extern int auto_center;
extern int auto_scale;
extern float line_width;
extern float root_search;

void errorm(void);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;


for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
  if(((argv[arg][1] == 'f') && (argv[arg][2] == 's')) ||  // -fs font_size
     ((argv[arg][1] == 's') && (argv[arg][2] == 'i') && (argv[arg][3] == 's') && (argv[arg][4] == 'i')))
   {
   arg ++;
   if(strlen(argv[arg]) >= 3)         // upto 2digit, no more than 99 pt for now
    errorm();
   if(strlen(argv[arg]) == 3)
    font_size = 100*((int)argv[arg][0]-48)+10*((int)argv[arg][1]-48)+((int)argv[arg][2]-48);
   if(strlen(argv[arg]) == 2)
    font_size = 10*((int)argv[arg][0]-48)+((int)argv[arg][1]-48);
   if(strlen(argv[arg]) == 1)
    font_size = (int)argv[arg][0]-48;
   }

  if(((argv[arg][1] == 'l') && (argv[arg][2] == 'w'))  || // -lw line_width
     ((argv[arg][1] == 'l') && (argv[arg][2] == 'i') && (argv[arg][3] == 'n') && (argv[arg][4] == 'e')))
   {
   arg ++;
   if(strlen(argv[arg]) >= 3)         // upto 2digit, no more than 9.9 pt for now
    errorm();
   if(strlen(argv[arg]) == 3)
    line_width = ((float)(100*((int)argv[arg][0]-48)+10*((int)argv[arg][1]-48)+((int)argv[arg][2]-48)))/10.0;
   if(strlen(argv[arg]) == 2)
    line_width = ((float)(10*((int)argv[arg][0]-48)+((int)argv[arg][1]-48)))/10.0;
   if(strlen(argv[arg]) == 1)
    line_width = ((float)(int)argv[arg][0]-48)/10.0;
   }

  if(((argv[arg][1] == 'f') && (argv[arg][2] == 'n')) ||  // -fn font_name
     ((argv[arg][1] == 'f') && (argv[arg][2] == 'o') && (argv[arg][3] == 'n') && (argv[arg][4] == 't')))
   {
   arg ++;
   strcpy(font_name,argv[arg]);
   }

  if(((argv[arg][1] == 't') && (argv[arg][2] == 'i')) ||  // -ti title
     ((argv[arg][1] == 't') && (argv[arg][2] == 'i') && (argv[arg][3] == 't') && (argv[arg][4] == 'l')))
   {
   arg ++;
   strcpy(title,argv[arg]);
   }

  if(((argv[arg][1] == 'c') && (argv[arg][2] == 's')) || // -cs caption_type
     ((argv[arg][1] == 'c') && (argv[arg][2] == 'a') && (argv[arg][3] == 'p') && (argv[arg][4] == 't')))
   {
   arg ++;
   if(argv[arg][0] == '1')
    caption_type = 1;
   if(argv[arg][0] == '2')
    caption_type = 2;
   if(argv[arg][0] == '3')
    caption_type = 3;
   }

  if(((argv[arg][1] == 'r') && (argv[arg][2] == 's'))  || // -rs root search
     ((argv[arg][1] == 'r') && (argv[arg][2] == 'o') && (argv[arg][3] == 'o')))
   {
   arg ++;
   if(argv[arg][0] == '0')
    root_search = 0;
   if(argv[arg][0] == '1')       // Phylogram
    root_search = 1;
   }

  if(((argv[arg][1] == 'm') && (argv[arg][2] == 't'))  || // -mt dmaptype
     ((argv[arg][1] == 'm') && (argv[arg][2] == 'a') && (argv[arg][3] == 'p')))
   {
   arg ++;
   if(argv[arg][0] == '0')
    dmaptype = 0;
   if(argv[arg][0] == '1')       // Phylogram
    dmaptype = 1;
   if(argv[arg][0] == '2')       // Dendrogram
    dmaptype = 2;
   if(argv[arg][0] == '3')
    dmaptype = 3;
   }

  if(((argv[arg][1] == 'b') && (argv[arg][2] == 's'))  || // -mt dmaptype
     ((argv[arg][1] == 'b') && (argv[arg][2] == 'o') && (argv[arg][3] == 'o')))
   {
   arg ++;
   if(argv[arg][0] == '0')       // NO BOOTSTRAP PRINT
    bootstrap = 0;
   if(argv[arg][0] == '1')       // BOOTSTRAP PRINT
    bootstrap = 1;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'h') && (argv[arg][3] == 'y'))
    dmaptype = 1;
  if((argv[arg][1] == 'd') && (argv[arg][2] == 'e') && (argv[arg][3] == 'n'))
    dmaptype = 2;
  if((argv[arg][1] == 'a') && (argv[arg][2] == '3'))
    paper_size = 3;
  if((argv[arg][1] == 'a') && (argv[arg][2] == '4'))
    paper_size = 4;
//  ///////////////////////////////////////////////////////// paper size option -sz  3:A3 4:A4
//  ///////////////////////////////////////////////////////// paper size option -sz  3:A3 4:A4
//  if((argv[arg][1] == 's') && (argv[arg][2] == 'i') && (argv[arg][3] == 'z') && (argv[arg][4] == 'e'))
//   {
//   arg ++;
//   if(argv[arg][0] == '3')
//    paper_size = 3;
//   else
//    {
//    if(argv[arg][0] == '4')
//     paper_size = 4;
//    else
//     errorm();
//    }
//   }
//  ///////////////////////////////////////////////////////// font size option -f : size(pt)
//  if(argv[arg][1] == 'f')
//   {
//   if(argv[arg][2] != '\0')
//    errorm();
//   else
//    {
//    arg ++;
//    if(strlen(argv[arg]) >= 3)         // upto 2digit, no more than 99 pt for now
//     errorm();
//    if(strlen(argv[arg]) == 3)
//     font_size = 100*((int)argv[arg][0]-48)+10*((int)argv[arg][1]-48)+((int)argv[arg][2]-48);
//    if(strlen(argv[arg]) == 2)
//     font_size = 10*((int)argv[arg][0]-48)+((int)argv[arg][1]-48);
//    if(strlen(argv[arg]) == 1)
//     font_size = (int)argv[arg][0]-48;
//    }
//   }
//  ///////////////////////////////////////////////////////// font size option -f : size(pt)
//  if(argv[arg][1] == '1')
//   font_size = 1;
//  if(argv[arg][1] == '2')
//   font_size = 2;
//  if(argv[arg][1] == '3')
//   font_size = 3;
//  ///////////////////////////////////////////////////////// paper size option -a3 : A3
//  if((argv[arg][1] == 'a') && (argv[arg][2] == '3'))
//   paper_size = 3;
//  ///////////////////////////////////////////////////////// paper direction option -side : side-way yoko
//  if((argv[arg][1] == 's') && (argv[arg][2] == 'i') && (argv[arg][3] == 'd') && (argv[arg][4] == 'e'))
//   direction  = 1;
//  /////////////////////////////////////////////////////////
  }
 else
  {
  sprintf(inflnm, "%s", argv[arg]);
  sprintf(outflnm,"%s.ps",argv[arg]);
  }
 }

if(inflnm[0] == '\0')
 errorm();
}


void errorm(void)
 {
 printf("ERROR\n");
 printf("Usage:   dendromat [-options] filename (input file is newick format, typically generated by clustalW or T_coffee .dnd, .phb etc)\n");
 printf("options: -fs         8   (Font size, default 10)\n");
 printf("         -fn   courier   (font name, default Helvetica)\n");
 printf("         -cs         1   (caption style, 1: Sideway, 2: Radial, 3: Radial Split, default 2)\n");
 printf("         -mt         1   (map type, 0: Cladogram, 1: Phylogram, 2: Dendrogram, default 2)\n");
 printf("         -lw         6   (line width, *0.1 point, default 10 = 1 point)\n");
 exit(1);
 }

