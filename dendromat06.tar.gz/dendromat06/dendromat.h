#define RAD_DEG  57.29577951
#define DEG_RAD  0.0174532925209

typedef struct node_element
 {
 int   pointer;      // negative # points to node, positive # points to terminal
 char  string[256];
 char  name[136];
 char  shortname[80];
 int   bootstrap;
 float distance;
 float guess_angle;
 int done_flag;
 float vert_pos;
 float horiz_pos;
 } node_element;

typedef struct node_data
 {
 int n_e;
 node_element ne[3];
 } node_data;

typedef struct node_info
 {
 float xx, yy;
 int node_id;
 int term_flag;
 char tag[136];
 } node_info;

typedef struct line_info
 {
 int fr_node, to_node;
 float angle, length;
 float frx, fry, tox, toy;
 int term_flag;
 int done_flag;
 int type;
 int bootstrap;
 int point[3];
 int i,j;
 } line_info;

typedef struct dend_info
 {
 int n_nodes;
 int n_lines;
 node_info *nodes;
 line_info *lines;
 } dend_info;

typedef struct term_info
 {
 char name[136];
 int name_len;
 float xx, yy;
 } term_info;

void read_newick (char *inflnm);
void mk_dendrogram(char *outflnm);
void mk_phylogram(char *outflnm);
void readargs(int argc, char **argv);
void find_center(void);
void mk_dendrogram2(char *outflnm);
void mk_phylogram2(char *outflnm);
