#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include "dendromat.h"

extern node_data *nodes;
extern line_info *lines;
extern int n_nodes;
extern int n_line;
extern int font_size;
extern int n_term;
extern term_info *terms;
extern int dmaptype;
extern int caption_type;
extern int auto_scale;
extern int auto_center;
extern float line_width;

extern char font_name[];
extern int separation;
extern int shift;
extern int page_height    ;   //A4 height pt = 209.17mm
extern int page_width     ;   //A4 width  pt = 295.8 mm
extern int page_height_a3 ;   //A3 height pt = 418.5 mm
extern int page_width_a3  ;   //A3 width  pt = 295.8 mm
extern int area_height    ;   //A3 width  pt = 295.8 mm
extern int area_width     ;   //A3 width  pt = 295.8 mm
extern int left_margin    ;
extern int right_margin   ;
extern int top_margin     ;
extern int bottom_margin  ;
extern int center_node;
extern int side;
extern int bs_flag;
extern char title[];

int nl2 = 0;
float longest_line  = 0.0;
float shortest_line = 999999.0;

void slide(double shiftx, double shifty, int currentline);

void define_lines(int point, int prev);

///////////////////////////////////////////////////////////////////// START mk_dendrogram2
void mk_dendrogram2(char *outflnm)
{
int i,j,k;
FILE *outfile;
float scale;
int nl = 0;
int cc;
float increment = 0.0;
float angle = 0.0;
float temp;
int count;
int all_done = 0;
int test;
float shiftx, shifty;
float sx, sy;
float length;
float leftmost = 999999.0;
float rightmost = -999999.0;
float upmost = -999999.0;
float downmost = 999999.0;
float width,height;
float sideshift;
float vertshift;
float ps_scale;
float temp1,temp2;
float a1,a2;
int fr, to;
///////////////////////////////////////////////////////////////////ALLOCATE STRUCTURE FOR lines
lines = (line_info *) malloc (sizeof(line_info) * (n_line + 5));
///////////////////////////////////////////////////////////////////ALLOCATE STRUCTURE FOR lines

nl2 = 0;                                 // counter for number of lines

////////////////////////////////////////////////////////////////// FILL STRUCTURE lines
for(i=0;i<3;i++)
 {
 fr = center_node;
 to = nodes[center_node].ne[i].pointer;
 lines[nl2].fr_node = fr;
 lines[nl2].to_node = to;
 lines[nl2].angle = 0.0;
 lines[nl2].length = fabs(nodes[center_node].ne[i].distance);
 if(lines[nl2].length > longest_line)
  longest_line = lines[nl2].length;
 if(lines[nl2].length < shortest_line)
  shortest_line = lines[nl2].length;
 lines[nl2].frx = 0.0;
 lines[nl2].fry = 0.0;
 lines[nl2].tox = 0.0;
 lines[nl2].toy = 0.0;
 lines[nl2].bootstrap = nodes[center_node].ne[i].bootstrap;
 lines[nl2].done_flag = 0;
 lines[nl2].type = 2;
 lines[nl2].point[0] = 0;
 lines[nl2].point[1] = 0;
 lines[nl2].i = fr;
 lines[nl2].j = 0;
 lines[nl2].term_flag = 0;
 lines[nl2].type = 1;
 nl2 ++;
 if(nodes[center_node].ne[i].pointer >= 0)
  define_lines(nodes[center_node].ne[i].pointer,center_node);      // CALL define_lines
 }
//////////////////////////////////////////////////////////////////  END FILLING STRUCTURE lines

////////////////////////////////////////////////////////////////// find id numbers of lines at the end of each lines
printf("NL2:%5d \n",nl2);
//for(i=0;i<nl2;i++)
// printf("%5d %5d\n",lines[i].fr_node,lines[i].to_node);

for(i=0;i<nl2;i++)
 for(j=0;j<3;j++)
  lines[i].point[j] = 0;

for(i=0;i<nl2;i++)
 {
 cc = 0;
 if(lines[i].to_node > 0)
  {
  for(j=0;j<nl2;j++)
   {
   if(lines[j].fr_node == lines[i].to_node)
    {
    lines[i].point[cc] = j+1;
    cc ++;
    }
   }
  }
 }
////////////////////////////////////////////////////////////////// 

//for(i=0;i<nl2;i++)
// printf("%5d %5d %5d\n",i,lines[i].fr_node,lines[i].to_node);
// //printf("%5d %5d %5d\n",lines[i].point[0],lines[i].point[1],lines[i].point[2]);
//for(i=0;i<n_term;i++)
// printf("TERM %3d %s \n", i+1,terms[i].name);

//////////////////////////////////////////////////////////////////  initialize line length
if(longest_line < 0.0000001)
 {
 for(i=0;i<nl2;i++)
  lines[i].length = 50.0;
 longest_line = 150.0;
 }
//////////////////////////////////////////////////////////////////  end initialize line length

scale = 200.0/longest_line;

increment = 360.0 / ((float)(n_term));

//printf("NUMBER OF TERMINAL NODE = %5d N_LINES %5d\n",n_term,nl2);

//////////////////////////////////////////////////////////////////  set end and start position of each line, for all terminal lines
for(i=1;i<=nl2;i++)
 {
 angle += increment;
 if(angle > 360.0)
  angle = 360.0;
 for(j=0;j<nl2;j++)
  {
  if(lines[j].to_node == -(i))
   {
   lines[j].angle = angle;
   lines[j].done_flag = 1;
   lines[j].frx = 0.0;
   lines[j].fry = 0.0;
   temp = angle * DEG_RAD;
   lines[j].tox = cos(temp) * lines[j].length;
   lines[j].toy = sin(temp) * lines[j].length;
   for(k=0;k<3;k++)
    nodes[lines[j].fr_node].ne[k].done_flag++;
//printf("INIT:%5d %5d %5d %10.4f %10.4f %10.4f=%10.4f %10.4f=%10.4f %5d\n",j,lines[j].fr_node,lines[j].to_node,angle,lines[j].length,lines[j].frx,lines[j].fry,lines[j].tox,lines[j].toy,lines[j].done_flag);
   break;
   }
  }
 }
//////////////////////////////////////////////////////////////////  set positions for terminal lines

//for(i=0;i<=nl2;i++)
// printf("LINES:%5d %5d %5d %10.4f %10.4f %10.4f=%10.4f %10.4f=%10.4f %5d\n",i,lines[i].fr_node,lines[i].to_node,lines[i].angle,lines[i].length,lines[i].frx,lines[i].fry,lines[i].tox,lines[i].toy,lines[i].done_flag);
// LOOP TO GROW THE TREE FROM INSIDE
count = 2;


printf("MARK2 \n");
//////////////////////////////////////////////////////////////////  grow non-terminal lines from inside(center_node)
while (all_done == 0)
 {
 for(i=0;i<nl2;i++)
  {
  if(lines[i].done_flag == 0)
   if(lines[i].to_node >= 0)
    {
    test = 0;
    for(j=0;j<3;j++)
     {
     if((nodes[lines[i].to_node].ne[j].pointer < 0) ||
        (nodes[lines[i].to_node].ne[j].done_flag == 2))
      test ++;
     }
    if(test == 3)
     {
     lines[i].done_flag = count;
     for(j=0;j<3;j++)
      nodes[lines[i].fr_node].ne[j].done_flag++;

     a1 = lines[lines[i].point[0]-1].angle;
     a2 = lines[lines[i].point[1]-1].angle;

     if(fabs(a2-a1) > 180.0000000)
      {
      angle = ((lines[lines[i].point[0]-1].angle + lines[lines[i].point[1]-1].angle) + 360.00000) / 2.000000000;
      }
     else
      {
      angle = (lines[lines[i].point[0]-1].angle + lines[lines[i].point[1]-1].angle) / 2.000000000;
      }


//     if(((a1 >= 0.0000000) && (a1 <= 90.0000000)) && ((a2 >= 270.0000000) && (a2 <= 360.0000000)))     // angle calculation exception
//      {
//      angle = (a1 + a2 - 360.0) / 2.0;
//      if(angle < 0.0)
//       angle = angle + 360.0;
//      }
//     else
//      {
//      if(((a2 >= 0.0000000) && (a2 <= 90.0000000)) && ((a1 >= 270.0000000) && (a1 <= 360.0000000)))   // angle calculation exception
//       {
//       angle = (a1 + a2 - 360.0) / 2.0;
//       if(angle < 0.0)
//        angle = angle + 360.0;
//       }
//      else
//       {
//       angle = (lines[lines[i].point[0]-1].angle + lines[lines[i].point[1]-1].angle) / 2.0;
//       }
//printf("%10.4f %10.4f %10.4f\n",a1,a2,angle);
//      }


     temp = angle * DEG_RAD;
     shiftx = cos(temp) * lines[i].length;
     shifty = sin(temp) * lines[i].length;
     lines[i].angle = angle;

     lines[i].tox += shiftx;
     lines[i].toy += shifty;
     lines[i].frx = 0.0;
     lines[i].fry = 0.0;

//printf("%5d %5d %5d %10.4f %10.4f %10.4f\n",i,lines[i].fr_node,lines[i].to_node,lines[i].length,shifty,shiftx);

     slide(shiftx,shifty,i);
     }
    }
  }

 all_done = 1;
 for(i=0;i<nl2;i++)
  {
  if(lines[i].done_flag == 0)
   {
   all_done = 0;
   }
  }

 count ++;
 }
///////////////////////////////////////////////////////////////// END grow lines from inside (center node)

//MARK
printf("MARK3\n");

//for(i=0;i<nl2;i++)
// printf("LINE %2d FROM %3d TO %3d POINT1 %3d POINT2 %3d DONE %1d TYPE %1d TERM %1d angle %8.3f length %10.6f frx %6.3f fry %6.3f tox %6.3f toy %6.3f\n",
//        i+1,
//        lines[i].fr_node,
//        lines[i].to_node,
//        lines[i].point[0],
//        lines[i].point[1],
//        lines[i].done_flag,
//        lines[i].type,
//        lines[i].term_flag,
//        lines[i].angle,
//        lines[i].length,
//        lines[i].frx,
//        lines[i].fry,
//        lines[i].tox,
//        lines[i].toy
//       );



if(!(outfile = fopen(outflnm,"w")))
 {
 printf("Failed to open output ps file %s.\n",outflnm);
 exit(1);
 }


////////////////////////////////////////////////////////////  Predetermin scale and centering numbers
for(i=0;i<nl2;i++)
 if(lines[i].term_flag == 1)
   {
   temp1 = (float)(lines[i].tox* scale);
   temp2 = 2.0 + ((float)font_size * 1.0 * ((float)(strlen(nodes[lines[i].i].ne[lines[i].j].name))));
   if(temp1 - temp2 < leftmost)
    leftmost = temp1-temp2;
   if(temp1 + temp2 > rightmost)
    rightmost = temp1 + temp2;

   temp1 = (float)(lines[i].toy* scale);
   temp2 = 2.0 + ((float)font_size * 0.5 );
   if(temp1 + temp2 > upmost)
    upmost = temp1 + temp2;
   if(temp1 - temp2  < downmost)
    downmost = temp1 - temp2;
   }

width = rightmost - leftmost;
height = upmost - downmost;
sideshift = -(rightmost + leftmost)/2.0;
vertshift = -(upmost + downmost)/2.0;
ps_scale = (page_width - 40.0) / width;
if((page_height / height) < ps_scale)
 ps_scale = (page_height - 40.0) / height;
printf("UPMOST %f DOWNMOST %f  RIGHTMOST %f LEFTMOST %f\n",upmost,downmost,rightmost,leftmost);
printf("WIDTH %f HEIGHT %f  \n",width,height);
printf("SIDESHIFT %f VERTSHIFT %f  \n",sideshift,vertshift);
printf("PS_SCALE %f\n",ps_scale);

ps_scale = ps_scale * 0.85;

////////////////////////////////////////////////////////////  END predetermine scale and centering numbers

////////////////////////////////////////////////////////////  Start creating PostScript file
// print PostScript header
// fputc('%',outfile);
 fprintf(outfile,"%%!PS-Adobe-\n%%Creator: kenske\n%%CreationDate: Sat Jul 19 16:15:35 2003\n%%DocumentFonts: (atend)\n");
 fprintf(outfile,"%%Pages: (atend)\n%%EndComments\n/mv {moveto} def\n");
 fprintf(outfile,"/right\n {      dup stringwidth pop\n        neg 0 rmoveto} bind def\n");
 fprintf(outfile,"/center\n {      dup stringwidth pop\n        2 div neg 0 rmoveto} bind def\n");
 fprintf(outfile,"%%EndProlog\n%%Page: 1\n");
// fprintf(outfile,"\n /%s findfont %3d scalefont setfont\n %d %d translate\n",font_name,font_size,page_width/2,page_height/2);

 fprintf(outfile,"\n /%s findfont 16 scalefont setfont\n\n", font_name);
 fprintf(outfile,"60 730 moveto\n (%s) show\n",title);

 fprintf(outfile,"\n /%s findfont %3d scalefont setfont\n %f %f translate %f %f scale\n",
        font_name,font_size,((float)page_width/2.0)+sideshift,((float)page_height/2.0)+vertshift,ps_scale,ps_scale);


// print PostScript lines
 for(i=0;i<nl2;i++)
  {
  fprintf(outfile,"%f %f moveto\n%f %f lineto\n",(float)(lines[i].frx * scale), (float)(lines[i].fry * scale), 
                                                 (float)(lines[i].tox * scale), (float)(lines[i].toy * scale));

  if(bs_flag == 1)
   {
   if(lines[i].term_flag == 0)
    {
    fprintf(outfile,"%f %f moveto\n",((float)(lines[i].frx * scale)+(float)(lines[i].tox * scale))/2.0, 
                                     ((float)(lines[i].fry * scale)+(float)(lines[i].toy * scale))/2.0);
    fprintf(outfile," (%d)",lines[i].bootstrap);
    fprintf(outfile,"show\n");
    }
   }
///////////////////////////////////////////////////////////// print PostScript captions
  if(lines[i].term_flag == 1)
   {
   if(caption_type == 1)    // Sideway
    {
    fprintf(outfile,"%f %f moveto", (float)(lines[i].tox * scale), (float)(lines[i].toy * scale));
    if((lines[i].angle <= 80.0) || (lines[i].angle >= 280.0))  // Right Side   
     fprintf(outfile," %d %f rmoveto",separation, -((float)font_size*0.7)/2.0);
    else
     if((lines[i].angle > 80.0) && (lines[i].angle <= 90.0))  // Right UP
      fprintf(outfile," %d %d rmoveto", -shift, separation);
     else
      if((lines[i].angle > 90.0) && (lines[i].angle <= 100.0))  // Left UP
       fprintf(outfile," %d %d rmoveto", shift, separation);
      else
       if((lines[i].angle > 100.0) && (lines[i].angle <= 260.0))  // Left Side
        fprintf(outfile," %d %f rmoveto", -separation, -((float)font_size*0.7)/2.0);
       else
        if((lines[i].angle > 260.0) && (lines[i].angle <= 270.0))  // Left Down
         fprintf(outfile," %d %f rmoveto", shift,-((float)separation+0.8*(float)font_size));
        else
         if((lines[i].angle > 270.0) && (lines[i].angle < 280.0))  // Right Down
          fprintf(outfile," %d %f rmoveto", -shift,-((float)separation+0.8*(float)font_size));
     
    fprintf(outfile," (%s)",nodes[lines[i].i].ne[lines[i].j].name);
    if((lines[i].angle < 90.0) || (lines[i].angle > 270.0))
     fprintf(outfile,"show\n");
    else
     fprintf(outfile,"right show\n");
    }
   else
    if(caption_type == 2)   // Umbrela
     {
     length = ((float)font_size * 0.7) / (2.0 * cos(20.0 * DEG_RAD));
     angle = lines[i].angle - 70.0;
     sx = length * cos(angle * DEG_RAD);
     sy = length * sin(angle * DEG_RAD);
     fprintf(outfile," %f %f rmoveto\n", sx, sy);
     fprintf(outfile," %f rotate\n", lines[i].angle);
     fprintf(outfile," (%s)",nodes[lines[i].i].ne[lines[i].j].name);
     fprintf(outfile,"show\n");
     fprintf(outfile," %f rotate\n", -lines[i].angle);
     }
    else
     if(caption_type == 3) // Se-wake
      {
      if((lines[i].angle <= 90.0) || (lines[i].angle >= 270.0))
       {
       length = ((float)font_size * 0.7) / (2.0 * cos(20.0 * DEG_RAD));
       angle = lines[i].angle - 70.0;
       sx = length * cos(angle * DEG_RAD);
       sy = length * sin(angle * DEG_RAD);
       fprintf(outfile," %f %f rmoveto\n", sx, sy);
       fprintf(outfile," %f rotate\n", lines[i].angle);
       fprintf(outfile," (%s)",nodes[lines[i].i].ne[lines[i].j].name);
       fprintf(outfile,"show\n");
       fprintf(outfile," %f rotate\n", -lines[i].angle);
       }
      else
       {
       length = ((float)font_size * 0.7) / (2.0 * cos(20.0 * DEG_RAD));
       angle = lines[i].angle + 70.0;
       sx = length * cos(angle * DEG_RAD);
       sy = length * sin(angle * DEG_RAD);
       fprintf(outfile," %f %f rmoveto\n", sx, sy);
       fprintf(outfile," %f rotate\n", lines[i].angle+180.0);
       fprintf(outfile," (%s)",nodes[lines[i].i].ne[lines[i].j].name);
       fprintf(outfile,"right  show\n");
       fprintf(outfile," %f rotate\n", -(lines[i].angle+180.0));
       }
      }
   }
  }
/////////////////////////////////////////////////////////////// END creating postscript file contents

/////////////////////////////////////////////////////////////// print PostScript footer
 fprintf(outfile,"%f setlinewidth\nstroke\nshowpage\n",line_width);
}
/////////////////////////////////////////////////////////////////////////////////// END mk_dendrogram2 



////////////////////////////////////////////////////////////////// START SUB FUNCTION define_lines

void define_lines(int point, int prev)
{
int i,j;
int fr,to;
for(i=0;i<3;i++)
 {
// printf("DEF %5d %5d\n",point,i);
 if(nodes[point].ne[i].pointer == prev)
  continue;
 fr = point;
 to = nodes[point].ne[i].pointer;
 if(to < 0)                               // hit terminal node
  {
  lines[nl2].fr_node = fr;
  lines[nl2].to_node = to;
  lines[nl2].angle = 0.0;
  lines[nl2].length = fabs(nodes[point].ne[i].distance);
  if(lines[nl2].length > longest_line)
   longest_line = lines[nl2].length;
  if(lines[nl2].length < shortest_line)
   shortest_line = lines[nl2].length;
  lines[nl2].frx = 0.0;
  lines[nl2].fry = 0.0;
  lines[nl2].tox = 0.0;
  lines[nl2].toy = 0.0;
  lines[nl2].done_flag = 0;
  lines[nl2].point[0] = 0;
  lines[nl2].point[1] = 0;
  lines[nl2].i = fr;
  lines[nl2].j = i;
  lines[nl2].term_flag = 1;
  lines[nl2].type = 1;
  nl2 ++;
  }
 else                                     // hit regular node
  {
  lines[nl2].fr_node = fr;
  lines[nl2].to_node = to;
  lines[nl2].angle = 0.0;  
  lines[nl2].length = fabs(nodes[point].ne[i].distance);
  if(lines[nl2].length > longest_line)
   longest_line = lines[nl2].length;
  if(lines[nl2].length < shortest_line)
   shortest_line = lines[nl2].length;
  lines[nl2].frx = 0.0;
  lines[nl2].fry = 0.0;
  lines[nl2].tox = 0.0;
  lines[nl2].toy = 0.0;
  lines[nl2].done_flag = 0;  
  lines[nl2].type = 2;     
  lines[nl2].bootstrap = nodes[point].ne[i].bootstrap;
//printf("BS %4d\n",lines[nl2].bootstrap);
  lines[nl2].point[0] = 0;
  lines[nl2].point[1] = 0;
  lines[nl2].term_flag = 0;
  lines[nl2].i = fr;      
  lines[nl2].j = i;
  if(fr == center_node)
   lines[nl2].type = 3;
  nl2 ++;
  if(to > 0)
   define_lines(to,fr);
  }
 }
return;
}
////////////////////////////////////////////////////////////////// END SUB FUNCTION define_lines
